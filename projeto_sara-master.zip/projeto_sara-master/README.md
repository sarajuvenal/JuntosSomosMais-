# 
Projeto alerta de localização

1. Explicando a ideia

	Conflitos entre estado (mesmo não institucional) versus minorias é secular, ainda nos tempos atuais vemos vários Estados pelo mundo reprimindo grupos por raça, gênero, orientação sexual, religião ou etnia.
	Casos gigantescos como o Massacre de Babi Yar, Carandiru, Massacre da Bósnia por Ratko Mladic, campos de concentração nazistas, apartheid africa do sul e caça aos homossexuais pelo governo russo são e/ou foram brutais mas não são apenas em grandes casos de genocídios como os citados acima que ocorrem mortes e perseguições há minorias, na verdade estes casos são o momento criticos de anos de conflitos anteriores que vão se institucionalizando.
	Hoje enquanto redijo este artigo vemos um momento deste, após a morte de George Floyd, um cidadão preto americano que foi abordado por policiais na cidade de minneapolis, transeuntes filmaram a abordagem e de acordo com os relatos destes o policial que o continha permaneceu mais de 8 minutos com o joelho sobre o seu pescoço.
	Estes e outros casos são relatados a décadas como corriqueiros neste País por cidadãos desta nação, mas diferente de décadas passadas o advento das mídias sociais trouxe uma nova arma, a capacidade de propagar de forma massiva estes casos para dentro e fora destes Estados o que gera comoção, empatia e revolta para os locais e estrangeiros.
	Mas a duvida fica, quantos casos como o de Floyd ocorre diariamente no mundo? Sempre terá uma pessoa próxima para denunciar este abuso? Com esta duvida que surgiu a ideia abaixo:
	Um aplicativo simples de duas telas;
	1) A primeira tela é a de alerta, ao abrir o app o sistema captura a localização e dispara para todos o usuários que também possuírem o app ao redor deste primeiro usuário informando que este se encontra em situação de perigo por notificação no celular.
	2) Na segunda tela fica um mapa que só é acessível ao clicar em uma notificação recebida, por ela você poderá ver a localização do primeiro que criou o chamado e como chegar no local para que assim consiga averiguar o ocorrido.
	Este sistema pode acabar se tornando um gerador de conflito por alguns entes, por esta razão considero mais adequado que os logs sejam confidenciais, ou idealmente não exista dados dos usuários no banco, sobre o banco por ser um sistema sem fins lucrativos este banco deve ser preferencialmente o mais enxuto possível para diminuir custos e construído de forma descentralizada para que outros entes possam mantê-lo a única senha necessária para ser criada é a senha para cancelar chamado, isto terá como objetivo prevenir que o agressor desative o sistema.


2. Detalhando o sistema

Banco de dados

	Partindo do principio acima, os dados do banco seriam os seguintes:
	
	Tabela Usuário:
	Usuário: O usuário será o registro de um ID gerada no ato da instalação, não sendo exibida ao usuário.
	Senha: A senha funcionará no mesmo método que a do usuário, assim protegendo o anonimato do usuário e ao mesmo tempo sua segurança.
	Latitude: A latitude é uma string que será constantemente capturada pelo app e enviada pelo sistema para o banco de dados, não será necessário uma tabela especifica para ela pois assim não teremos registro do histórico do usuário.
	Longitude: A longitude é uma string que será constantemente capturada pelo app e enviada pelo sistema para o banco de dados, não será necessário uma tabela especifica para ela pois assim não teremos registro do histórico do usuário.
	Senha de cancelamento: Senha solicitada para desativar o chamado aberto.

	Tabela chamado:
	ID: Código de chamado do registro.
	Código do usuário que abriu o chamado: chave estrangeira para realizar uma consulta constante e atualização da latitude e longitude do usuário.
	Latitude: A latitude será atualizada para manter a posição do chamado atualizado.
	Longitude: A longitude será atualizada para manter a posição do chamado atualizado.


Tela chamado

	Ao clicar no app ele carregará uma tela preta apenas com um input de texto para receber a senha do cancelamento do input que ao digitá-la corretamente encerrará o app e fechará o chamado.

Tela resgate

	A tela de resgate abrirá somente ao clicar numa notificação, ela será um mapa com a navegação até a pessoa que solicitou, esta poderá ser fechada sem problemas.
